using UnityEngine;

/// <summary>
/// SimpleIslandGenerator — Procedural island for isometric traversal.
/// 
/// KEY FIXES:
///   - Terrain coloring via TEXTURE (vertex colors don't work with URP Lit/Standard)
///   - Mountain is VERY steep and obvious (cone shape, not gentle gaussian)
///   - Rivers are extremely wide (carved AFTER smoothing)
///   - Trees, rocks, and proper lit shading
/// </summary>
public class SimpleIslandGenerator : MonoBehaviour
{
    [Header("Island Size")]
    public int terrainSize = 725;
    public float terrainHeight = 42f;
    public int resolution = 300;

    [Header("Generation")]
    public bool randomizeSeedOnStart = true;
    public int seed = 42;

    [Header("Terrain Style")]
    public float baseNoiseScale = 3.8f;
    public float hillNoiseScale = 7.2f;
    public float mountainNoiseScale = 13f;
    [Range(0f, 1f)] public float hillStrength = 0.82f;
    [Range(0f, 1f)] public float mountainStrength = 1f;
    [Range(0f, 1f)] public float ridgeStrength = 0.56f;
    [Range(0f, 0.9f)] public float heightCompression = 0.08f;

    [Header("Legacy")]
    public float ridgeNoiseScale = 0f;
    [Range(0f, 1f)] public float flatlandStrength = 0.48f;
    [Range(0f, 1f)] public float flatness = 0.62f;
    [Range(0, 20)] public int terraceSteps = 0;

    [Header("Island Shape")]
    [Range(1.4f, 5f)] public float islandFalloff = 2.8f;
    [Range(0.55f, 0.95f)] public float oceanStart = 0.78f;

    [Header("Water")]
    public float waterWorldY = 1.5f;
    public float oceanFloorDepth = 8f;
    [Range(0f, 1f)] public float inlandWaterStrength = 0.3f;
    public Color waterColor = new Color(0.08f, 0.35f, 0.6f, 0.75f);

    [Header("Terrain Heights")]
    public float landFloorY = 3.5f;
    public float peakY = 42f;

    [Header("Smoothing")]
    [Range(0f, 1f)] public float smoothingStrength = 0.28f;
    [Range(0, 6)] public int smoothingIterations = 2;

    [Header("Vegetation")]
    public int treeCount = 350;
    public int rockCount = 120;

    // Legacy hidden fields
    [HideInInspector] public float waterLevel = 0f;
    [HideInInspector] public float oceanDepth = 0f;
    [HideInInspector] public float inlandLandLift = 0f;
    [HideInInspector] public float waterPlaneYOffset = 0f;

    private GameObject islandObj;
    private GameObject waterObj;
    private float[,] heightmap;

    // Stored for post-smooth carving
    private int _riverCount;
    private Vector2[] _riverStart, _riverEnd;
    private Vector2[] _lakeCenters;
    private Vector2 _oRidge, _oRiver;

    void Start()
    {
        if (randomizeSeedOnStart)
            seed = Random.Range(int.MinValue, int.MaxValue);

        try
        {
            GenerateIsland();
            CreateWaterPlane();
            SpawnVegetation();
            SpawnLandmarks();
            PositionPlayerAboveTerrain();
            LogHeightStats();
        }
        catch (System.Exception e)
        {
            Debug.LogError($"🐚 FAILED: {e.Message}\n{e.StackTrace}");
            CreateFallbackGround();
        }
    }

    void LogHeightStats()
    {
        if (heightmap == null) return;
        float min = float.MaxValue, max = float.MinValue;
        int size = resolution + 1;
        int belowWater = 0, total = size * size;
        for (int z = 0; z < size; z++)
            for (int x = 0; x < size; x++)
            {
                float h = heightmap[z, x];
                if (h < min) min = h;
                if (h > max) max = h;
                if (h < waterWorldY) belowWater++;
            }
        float range = max - min;
        Debug.Log($"🐚 HEIGHTS: min={min:F1} max={max:F1} range={range:F1} belowWater={100f * belowWater / total:F0}%");
        Debug.Log($"🐚 Mountain should peak at ~{max:F1}, flat land ~{landFloorY + 2:F1}, water at {waterWorldY}");
    }

    public void GenerateIsland()
    {
        if (islandObj != null) Destroy(islandObj);

        heightmap = GenerateHeightmap();
        Mesh mesh = BuildMesh(heightmap);
        Texture2D tex = BakeTerrainTexture(heightmap);

        islandObj = new GameObject("Island");
        islandObj.transform.position = Vector3.zero;

        var mf = islandObj.AddComponent<MeshFilter>();
        mf.mesh = mesh;

        var mr = islandObj.AddComponent<MeshRenderer>();
        mr.material = CreateLitTexturedMaterial(tex);

        var mc = islandObj.AddComponent<MeshCollider>();
        mc.sharedMesh = mesh;
    }

    // ═══════════════════════════════════════════════
    // HEIGHTMAP GENERATION
    // ═══════════════════════════════════════════════

    float[,] GenerateHeightmap()
    {
        int size = resolution + 1;
        float[,] h = new float[size, size];

        Random.InitState(seed);
        Vector2 oBase = RndOff(), oHill = RndOff(), oMtn = RndOff();
        _oRidge = RndOff(); _oRiver = RndOff();

        // ── MOUNTAIN: near center, TIGHT radius ──
        Vector2 mtnCenter = Random.insideUnitCircle.normalized * Random.Range(0.03f, 0.12f);
        float mtnRadius = Random.Range(0.06f, 0.10f);

        // ── HILLS ──
        Vector2[] hillC = new Vector2[3];
        float[] hillR = new float[3];
        for (int i = 0; i < 3; i++)
        {
            float a = Random.Range(0f, Mathf.PI * 2f);
            hillC[i] = new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * Random.Range(0.10f, 0.32f);
            hillR[i] = Random.Range(0.04f, 0.08f);
        }

        // ── RIVERS ──
        _riverCount = 2;
        _riverStart = new Vector2[_riverCount];
        _riverEnd = new Vector2[_riverCount];
        for (int i = 0; i < _riverCount; i++)
        {
            float a0 = Random.Range(0f, Mathf.PI * 2f);
            _riverStart[i] = new Vector2(Mathf.Cos(a0), Mathf.Sin(a0)) * Random.Range(0.02f, 0.08f);
            float a1 = a0 + Random.Range(-0.5f, 0.5f);
            _riverEnd[i] = new Vector2(Mathf.Cos(a1), Mathf.Sin(a1)) * Random.Range(0.60f, 0.80f);
        }

        // ── LAKES ──
        _lakeCenters = new Vector2[3];
        for (int i = 0; i < 3; i++)
        {
            float a = Random.Range(0f, Mathf.PI * 2f);
            _lakeCenters[i] = new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * Random.Range(0.15f, 0.30f);
        }

        float oceanFloor = waterWorldY - oceanFloorDepth;
        float hRange = peakY - landFloorY;

        // ════════════════════════════════
        // PASS 1: Base terrain
        // ════════════════════════════════
        for (int z = 0; z <= resolution; z++)
        {
            for (int x = 0; x <= resolution; x++)
            {
                float nx = (float)x / resolution;
                float nz = (float)z / resolution;
                Vector2 p = new Vector2(nx - 0.5f, nz - 0.5f);
                float dist = p.magnitude * 2f;

                // Island mask
                float cw = (Mathf.PerlinNoise(_oRidge.x + nx * 5f, _oRidge.y + nz * 5f) - 0.5f) * 0.25f;
                float wd = Mathf.Clamp01(dist + cw);
                float mask = 1f - Mathf.Pow(Mathf.Clamp01(wd), islandFalloff);
                mask = Mathf.SmoothStep(0f, 1f, mask);

                // Noise
                float b = Fbm(nx, nz, baseNoiseScale, 4, 0.5f, oBase);
                float hi = Fbm(nx, nz, hillNoiseScale, 3, 0.5f, oHill);
                float mt = Fbm(nx, nz, mountainNoiseScale, 3, 0.55f, oMtn);
                float rf = ridgeNoiseScale > 0.01f ? ridgeNoiseScale : mountainNoiseScale * 0.72f;
                float ri = Ridged(nx, nz, rf, _oRidge);

                // ── MOUNTAIN: steep cone shape ──
                float md = Vector2.Distance(p, mtnCenter);
                // Linear falloff = cone, not bell curve
                float mtn = Mathf.Clamp01(1f - md / mtnRadius);
                // Pow < 1 makes it convex (steeper near base, plateau at top)
                mtn = Mathf.Pow(mtn, 0.35f);

                // ── HILLS ──
                float hill = 0f;
                for (int i = 0; i < hillC.Length; i++)
                {
                    float hd = Vector2.Distance(p, hillC[i]);
                    float hh = Mathf.Clamp01(1f - hd / hillR[i]);
                    hh = Mathf.Pow(hh, 0.5f);
                    hill = Mathf.Max(hill, hh);
                }

                // Combine
                float t = b * 0.08f;
                t += hi * hillStrength * 0.06f;
                t += (mt + ri * ridgeStrength) * mountainStrength * 0.05f;
                t += mtn * 0.92f;   // Mountain: almost full height range
                t += hill * 0.35f;  // Hills: about 1/3 of range

                t = Mathf.Lerp(t, Mathf.Sqrt(Mathf.Max(0f, t)), heightCompression);

                float worldY = landFloorY + t * hRange;
                worldY = Mathf.Lerp(oceanFloor, worldY, mask);

                // Safety floor
                worldY = Mathf.Max(worldY, Mathf.Lerp(oceanFloor, waterWorldY + 1.5f, mask));

                h[z, x] = worldY;
            }
        }

        // ════════════════════════════════
        // PASS 2: Smooth
        // ════════════════════════════════
        h = Smooth(h);

        // ════════════════════════════════
        // PASS 3: Carve water AFTER smooth
        // ════════════════════════════════
        CarveWater(h);

        return h;
    }

    void CarveWater(float[,] h)
    {
        float carveY = waterWorldY - 2f;

        for (int z = 0; z <= resolution; z++)
        {
            for (int x = 0; x <= resolution; x++)
            {
                float nx = (float)x / resolution;
                float nz = (float)z / resolution;
                Vector2 p = new Vector2(nx - 0.5f, nz - 0.5f);
                float dist = p.magnitude * 2f;

                // Island mask
                float cw = (Mathf.PerlinNoise(_oRidge.x + nx * 5f, _oRidge.y + nz * 5f) - 0.5f) * 0.25f;
                float wd = Mathf.Clamp01(dist + cw);
                float mask = 1f - Mathf.Pow(Mathf.Clamp01(wd), islandFalloff);
                mask = Mathf.SmoothStep(0f, 1f, mask);
                if (mask < 0.15f) continue;

                // ── RIVERS: VERY WIDE ──
                float rv = 0f;
                for (int i = 0; i < _riverCount; i++)
                {
                    float d = DistToSeg(p, _riverStart[i], _riverEnd[i]);
                    // Width: 0.02 to 0.06 in normalized = 14 to 43 world units
                    float w = Mathf.Lerp(0.02f, 0.06f, Mathf.InverseLerp(0.05f, 0.75f, dist));
                    // Meandering noise
                    float mn = Mathf.PerlinNoise(_oRiver.x + nx * 6f, _oRiver.y + nz * 6f);
                    w *= Mathf.Lerp(0.7f, 1.3f, mn);
                    float rc = 1f - Mathf.SmoothStep(0f, w, d);
                    rv = Mathf.Max(rv, rc);
                }
                rv *= Mathf.SmoothStep(0.03f, 0.2f, dist);

                // ── LAKES: BIG ──
                float lk = 0f;
                for (int i = 0; i < _lakeCenters.Length; i++)
                {
                    float ld = Vector2.Distance(p, _lakeCenters[i]);
                    // 0.04 to 0.12 = 29 to 87 world units diameter
                    lk = Mathf.Max(lk, 1f - Mathf.SmoothStep(0.04f, 0.12f, ld));
                }

                float carve = Mathf.Max(rv, lk);
                if (carve > 0.01f)
                {
                    h[z, x] = Mathf.Lerp(h[z, x], carveY, carve);
                }
            }
        }
    }

    // ═══════════════════════════════════════════════
    // TEXTURE BAKING — works with ANY shader
    // ═══════════════════════════════════════════════

    Texture2D BakeTerrainTexture(float[,] heights)
    {
        int size = resolution + 1;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGB24, true);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;

        // Pre-compute normals for slope detection
        float cellSize = (float)terrainSize / resolution;

        Color[] pixels = new Color[size * size];

        for (int z = 0; z < size; z++)
        {
            for (int x = 0; x < size; x++)
            {
                float y = heights[z, x];
                float heightPct = Mathf.InverseLerp(landFloorY, peakY, y);

                // Compute slope from neighbors
                float hL = heights[z, Mathf.Max(0, x - 1)];
                float hR = heights[z, Mathf.Min(resolution, x + 1)];
                float hD = heights[Mathf.Max(0, z - 1), x];
                float hU = heights[Mathf.Min(resolution, z + 1), x];
                Vector3 normal = new Vector3(hL - hR, 2f * cellSize, hD - hU).normalized;
                float slope = Mathf.Acos(Mathf.Clamp(normal.y, -1f, 1f)) * Mathf.Rad2Deg;

                Color c;

                // ── Color by height + slope ──
                if (y < waterWorldY - 0.5f)
                {
                    // Underwater: dark blue-brown
                    c = new Color(0.20f, 0.25f, 0.30f);
                }
                else if (y < waterWorldY + 1.5f)
                {
                    // Beach sand
                    c = new Color(0.76f, 0.70f, 0.50f);
                }
                else if (y < waterWorldY + 3.5f)
                {
                    // Sand → grass transition
                    float t = Mathf.InverseLerp(waterWorldY + 1.5f, waterWorldY + 3.5f, y);
                    c = Color.Lerp(new Color(0.76f, 0.70f, 0.50f), new Color(0.30f, 0.55f, 0.18f), t);
                }
                else if (slope > 50f)
                {
                    // Cliff rock
                    c = new Color(0.40f, 0.38f, 0.35f);
                }
                else if (slope > 30f)
                {
                    float t = (slope - 30f) / 20f;
                    c = Color.Lerp(new Color(0.45f, 0.35f, 0.20f), new Color(0.40f, 0.38f, 0.35f), t);
                }
                else if (heightPct > 0.88f)
                {
                    // Snow
                    float t = Mathf.InverseLerp(0.88f, 1f, heightPct);
                    c = Color.Lerp(new Color(0.42f, 0.40f, 0.38f), new Color(0.92f, 0.92f, 0.96f), t);
                }
                else if (heightPct > 0.65f)
                {
                    // Alpine rock
                    float t = Mathf.InverseLerp(0.65f, 0.88f, heightPct);
                    c = Color.Lerp(new Color(0.18f, 0.35f, 0.12f), new Color(0.42f, 0.40f, 0.38f), t);
                }
                else if (heightPct > 0.35f)
                {
                    // Dark forest green
                    float t = Mathf.InverseLerp(0.35f, 0.65f, heightPct);
                    c = Color.Lerp(new Color(0.25f, 0.50f, 0.15f), new Color(0.18f, 0.35f, 0.12f), t);
                }
                else
                {
                    // Light grassland
                    c = new Color(0.30f, 0.55f, 0.18f);
                }

                // ── Baked directional lighting ──
                Vector3 lightDir = new Vector3(0.5f, 0.85f, 0.25f).normalized;
                float NdotL = Vector3.Dot(normal, lightDir);
                float shade = Mathf.Lerp(0.45f, 1.2f, Mathf.Clamp01(NdotL));
                c *= shade;

                // ── Fake AO: valleys darker ──
                float ao = Mathf.Lerp(0.6f, 1f, Mathf.InverseLerp(waterWorldY, waterWorldY + 12f, y));
                c *= ao;

                c.r = Mathf.Clamp01(c.r);
                c.g = Mathf.Clamp01(c.g);
                c.b = Mathf.Clamp01(c.b);

                pixels[z * size + x] = c;
            }
        }

        tex.SetPixels(pixels);
        tex.Apply(true);
        return tex;
    }

    // ═══════════════════════════════════════════════
    // VEGETATION
    // ═══════════════════════════════════════════════

    void SpawnVegetation()
    {
        GameObject parent = new GameObject("Vegetation");
        Random.InitState(seed + 777);

        float minH = waterWorldY + 2.5f;
        float treeLine = peakY * 0.65f;

        // ── Trees ──
        int trees = 0;
        for (int att = 0; att < treeCount * 4 && trees < treeCount; att++)
        {
            float range = terrainSize * 0.40f;
            float wx = Random.Range(-range, range);
            float wz = Random.Range(-range, range);
            float y = SampleHeight(wx, wz);
            if (y < minH || y > treeLine) continue;

            GameObject tree = new GameObject($"Tree_{trees}");
            tree.transform.parent = parent.transform;

            // Trunk
            var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            trunk.transform.parent = tree.transform;
            float tH = Random.Range(2f, 4.5f);
            float tW = Random.Range(0.2f, 0.45f);
            trunk.transform.localScale = new Vector3(tW, tH * 0.5f, tW);
            trunk.transform.position = new Vector3(wx, y + tH * 0.5f, wz);
            trunk.GetComponent<Renderer>().material = MakeMat(
                new Color(0.32f + Random.value * 0.12f, 0.20f + Random.value * 0.08f, 0.08f));
            Destroy(trunk.GetComponent<Collider>());

            // Canopy
            bool pine = Random.value > 0.45f;
            GameObject canopy;
            if (pine)
            {
                canopy = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                float cH = Random.Range(2.5f, 5f), cW = Random.Range(1f, 2f);
                canopy.transform.localScale = new Vector3(cW, cH * 0.5f, cW);
                canopy.transform.position = new Vector3(wx, y + tH + cH * 0.25f, wz);
            }
            else
            {
                canopy = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                float cR = Random.Range(1.3f, 2.8f);
                canopy.transform.localScale = new Vector3(cR, cR * 0.75f, cR);
                canopy.transform.position = new Vector3(wx, y + tH + cR * 0.25f, wz);
            }
            canopy.transform.parent = tree.transform;
            canopy.GetComponent<Renderer>().material = MakeMat(
                new Color(0.08f + Random.value * 0.18f, 0.28f + Random.value * 0.30f, 0.04f + Random.value * 0.08f));
            Destroy(canopy.GetComponent<Collider>());

            trees++;
        }

        // ── Rocks ──
        int rocks = 0;
        for (int att = 0; att < rockCount * 4 && rocks < rockCount; att++)
        {
            float range = terrainSize * 0.42f;
            float wx = Random.Range(-range, range);
            float wz = Random.Range(-range, range);
            float y = SampleHeight(wx, wz);
            if (y < minH) continue;

            var rock = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            rock.name = $"Rock_{rocks}";
            rock.transform.parent = parent.transform;
            float sx = Random.Range(0.4f, 2f), sy = Random.Range(0.2f, 1.2f), sz = Random.Range(0.4f, 2f);
            rock.transform.localScale = new Vector3(sx, sy, sz);
            rock.transform.position = new Vector3(wx, y + sy * 0.3f, wz);
            rock.transform.rotation = Quaternion.Euler(Random.Range(0f, 15f), Random.Range(0f, 360f), Random.Range(0f, 15f));
            float g = Random.Range(0.28f, 0.50f);
            rock.GetComponent<Renderer>().material = MakeMat(new Color(g, g - 0.02f, g - 0.04f));
            Destroy(rock.GetComponent<Collider>());
            rocks++;
        }

        Debug.Log($"🐚 Vegetation: {trees} trees, {rocks} rocks");
    }

    // ═══════════════════════════════════════════════
    // MESH
    // ═══════════════════════════════════════════════

    Mesh BuildMesh(float[,] heights)
    {
        int vx = resolution + 1, vz = vx;
        int total = vx * vz;
        var verts = new Vector3[total];
        var uvs = new Vector2[total];
        var tris = new int[resolution * resolution * 6];

        float half = terrainSize / 2f;
        float step = (float)terrainSize / resolution;

        for (int z = 0; z <= resolution; z++)
            for (int x = 0; x <= resolution; x++)
            {
                int i = z * vx + x;
                verts[i] = new Vector3(x * step - half, heights[z, x], z * step - half);
                uvs[i] = new Vector2((float)x / resolution, (float)z / resolution);
            }

        int t = 0;
        for (int z = 0; z < resolution; z++)
            for (int x = 0; x < resolution; x++)
            {
                int bl = z * vx + x, br = bl + 1;
                int tl = (z + 1) * vx + x, tr = tl + 1;
                tris[t++] = bl; tris[t++] = tl; tris[t++] = tr;
                tris[t++] = bl; tris[t++] = tr; tris[t++] = br;
            }

        Mesh m = new Mesh();
        m.name = "IslandMesh";
        if (total > 65535) m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        m.vertices = verts;
        m.triangles = tris;
        m.uv = uvs;
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }

    // ═══════════════════════════════════════════════
    // WATER
    // ═══════════════════════════════════════════════

    void CreateWaterPlane()
    {
        if (waterObj != null) Destroy(waterObj);
        waterObj = GameObject.CreatePrimitive(PrimitiveType.Plane);
        waterObj.name = "WaterPlane";
        waterObj.transform.position = new Vector3(0f, waterWorldY, 0f);
        float s = terrainSize / 10f * 1.6f;
        waterObj.transform.localScale = new Vector3(s, 1f, s);
        var rend = waterObj.GetComponent<Renderer>();
        rend.material = MakeTransparent(waterColor);
        rend.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        rend.receiveShadows = false;
        Destroy(waterObj.GetComponent<Collider>());
        Debug.Log($"🐚 Water at Y={waterWorldY}");
    }

    // ═══════════════════════════════════════════════
    // PLAYER + LANDMARKS
    // ═══════════════════════════════════════════════

    void PositionPlayerAboveTerrain()
    {
        var player = GameObject.Find("Player");
        if (player == null) player = GameObject.FindGameObjectWithTag("Player");
        if (player == null) return;

        float minH = waterWorldY + 3f;
        float bx = 0f, bz = 0f, bh = SampleHeight(0f, 0f);
        for (int i = 0; i < 40; i++)
        {
            float tx = Random.Range(-60f, 60f), tz = Random.Range(-60f, 60f);
            float th = SampleHeight(tx, tz);
            if (th > minH && (bh < minH || th < bh)) { bx = tx; bz = tz; bh = th; }
        }
        if (bh < minH) { bx = 0f; bz = 0f; bh = SampleHeight(0f, 0f); }

        player.transform.position = new Vector3(bx, bh + 3f, bz);
        var rb = player.GetComponent<Rigidbody>();
        if (rb != null) { rb.linearVelocity = Vector3.zero; rb.angularVelocity = Vector3.zero; }
        Debug.Log($"🐚 Player at ({bx:F0},{bh + 3f:F1},{bz:F0}), terrain={bh:F1}");
    }

    void SpawnLandmarks()
    {
        var parent = new GameObject("Landmarks");
        Color[] mc = {
            new Color(0.9f,0.3f,0.2f), new Color(0.2f,0.4f,0.9f),
            new Color(0.9f,0.8f,0.1f), new Color(0.8f,0.2f,0.8f),
        };
        Random.InitState(seed + 999);
        int placed = 0;
        for (int a = 0; a < 80 && placed < 8; a++)
        {
            float r = terrainSize * 0.32f;
            float x = Random.Range(-r, r), z = Random.Range(-r, r);
            float y = SampleHeight(x, z);
            if (y < waterWorldY + 2f) continue;
            var p = GameObject.CreatePrimitive(PrimitiveType.Cube);
            p.name = $"Landmark_{placed}"; p.transform.parent = parent.transform;
            float ph = Random.Range(4f, 8f);
            p.transform.localScale = new Vector3(1.5f, ph, 1.5f);
            p.transform.position = new Vector3(x, y + ph / 2f, z);
            p.GetComponent<Renderer>().material = MakeMat(mc[placed % mc.Length]);
            placed++;
        }
    }

    // ═══════════════════════════════════════════════
    // HEIGHT SAMPLING
    // ═══════════════════════════════════════════════

    public float SampleHeight(float wx, float wz)
    {
        if (heightmap == null) return 0f;
        float half = terrainSize / 2f;
        float hx = ((wx + half) / terrainSize) * resolution;
        float hz = ((wz + half) / terrainSize) * resolution;
        int x0 = Mathf.Clamp(Mathf.FloorToInt(hx), 0, resolution - 1);
        int z0 = Mathf.Clamp(Mathf.FloorToInt(hz), 0, resolution - 1);
        int x1 = Mathf.Min(x0 + 1, resolution), z1 = Mathf.Min(z0 + 1, resolution);
        float tx = hx - x0, tz = hz - z0;
        return Mathf.Lerp(
            Mathf.Lerp(heightmap[z0, x0], heightmap[z0, x1], tx),
            Mathf.Lerp(heightmap[z1, x0], heightmap[z1, x1], tx), tz);
    }

    // ═══════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════

    Vector2 RndOff() => new Vector2(Random.value * 10000f, Random.value * 10000f);

    float Fbm(float x, float z, float scale, int oct, float pers, Vector2 off)
    {
        float v = 0f, a = 1f, f = scale, ta = 0f;
        for (int i = 0; i < oct; i++)
        {
            v += Mathf.PerlinNoise(off.x + x * f, off.y + z * f) * a;
            ta += a; a *= pers; f *= 2f;
        }
        return ta > 0f ? v / ta : 0f;
    }

    float Ridged(float x, float z, float scale, Vector2 off)
    {
        float n = Mathf.PerlinNoise(off.x + x * scale, off.y + z * scale);
        n = 1f - Mathf.Abs(n * 2f - 1f);
        return n * n;
    }

    float DistToSeg(Vector2 p, Vector2 a, Vector2 b)
    {
        Vector2 ab = b - a;
        float d = ab.sqrMagnitude;
        if (d < 0.0001f) return Vector2.Distance(p, a);
        float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / d);
        return Vector2.Distance(p, a + ab * t);
    }

    float[,] Smooth(float[,] src)
    {
        if (smoothingStrength <= 0f || smoothingIterations <= 0) return src;
        int sz = resolution + 1;
        var cur = src;
        for (int pass = 0; pass < smoothingIterations; pass++)
        {
            var nxt = new float[sz, sz];
            for (int z = 0; z < sz; z++)
                for (int x = 0; x < sz; x++)
                {
                    float s = 0f; int c = 0;
                    for (int dz = -1; dz <= 1; dz++)
                    {
                        int zz = z + dz; if (zz < 0 || zz >= sz) continue;
                        for (int dx = -1; dx <= 1; dx++)
                        {
                            int xx = x + dx; if (xx < 0 || xx >= sz) continue;
                            s += cur[zz, xx]; c++;
                        }
                    }
                    nxt[z, x] = Mathf.Lerp(cur[z, x], s / c, smoothingStrength);
                }
            cur = nxt;
        }
        return cur;
    }

    // ═══════════════════════════════════════════════
    // MATERIALS
    // ═══════════════════════════════════════════════

    Material CreateLitTexturedMaterial(Texture2D tex)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Diffuse");
        if (shader == null) return MakeMat(Color.green);

        Material mat = new Material(shader);
        mat.name = "TerrainTextured";
        mat.mainTexture = tex;
        mat.color = Color.white;
        if (mat.HasProperty("_BaseMap")) mat.SetTexture("_BaseMap", tex);
        if (mat.HasProperty("_MainTex")) mat.SetTexture("_MainTex", tex);
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", Color.white);
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", Color.white);

        // Metallic/smoothness down for matte look
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", 0f);
        if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", 0.1f);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", 0.1f);

        return mat;
    }

    Material MakeMat(Color color)
    {
        Shader sh = Shader.Find("Universal Render Pipeline/Lit");
        if (sh == null) sh = Shader.Find("Standard");
        if (sh == null) sh = Shader.Find("Diffuse");
        if (sh == null) return new Material(Shader.Find("Hidden/InternalErrorShader"));
        var m = new Material(sh);
        m.color = color;
        if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", color);
        if (m.HasProperty("_Color")) m.SetColor("_Color", color);
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", 0.15f);
        return m;
    }

    Material MakeTransparent(Color color)
    {
        Shader sh = Shader.Find("Universal Render Pipeline/Lit");
        bool urp = sh != null;
        if (!urp) sh = Shader.Find("Standard");
        if (sh == null) { sh = Shader.Find("Sprites/Default"); if (sh == null) return MakeMat(color); var fb = new Material(sh); fb.color = color; return fb; }

        var mat = new Material(sh);
        mat.name = "WaterTransparent";
        if (urp)
        {
            mat.SetFloat("_Surface", 1f);
            mat.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
            mat.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            mat.SetFloat("_ZWrite", 0f);
            mat.SetOverrideTag("RenderType", "Transparent");
            mat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
            mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            mat.SetColor("_BaseColor", color);
        }
        else
        {
            mat.SetFloat("_Mode", 3f);
            mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            mat.SetInt("_ZWrite", 0);
            mat.EnableKeyword("_ALPHAPREMULTIPLY_ON");
            mat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
            mat.SetColor("_Color", color);
        }
        mat.color = color;
        return mat;
    }

    void CreateFallbackGround()
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Plane);
        g.name = "Island"; g.transform.position = new Vector3(0f, landFloorY, 0f);
        g.transform.localScale = new Vector3(terrainSize / 10f, 1f, terrainSize / 10f);
        g.GetComponent<Renderer>().material = MakeMat(Color.green);
    }
}
